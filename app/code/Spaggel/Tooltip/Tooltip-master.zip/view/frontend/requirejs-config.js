var config = {
    map: {
        "*": {
            "Tooltipster": "Spaggel_Tooltip/js/tooltip.wrapper",
            "SwatchRenderer": "Spaggel_Tooltip/js/swatch-renderer"
        }
    },
    shim: {
        "Spaggel_Tooltip/js/tooltipster.bundle.min": ["jquery"]
    }
};